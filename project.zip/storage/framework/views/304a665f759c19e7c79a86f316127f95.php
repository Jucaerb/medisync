<?php $__env->startSection('content'); ?>

    <div class="d-flex p-4">
        <div class="container">
            <p class="card-title text-aling-left text-body-title2 pb-3">Mira las actividades de tus pacientes</p>
            <div class="card mb-3 border-0 ">
                
                <div class="card-header border-0">
                    <form action="<?php echo e(route('dashboardpatient')); ?>" method="get">
                        <div class="d-flex flex-row align-items-start">
                            <input type="text" class="form-control busqueda" name="texto" value="<?php echo e($texto); ?>">
                            <input type="submit" class="btn btn-primary mx-2 button-buscar" value="Buscar">
                        </div>
                    </form>
                </div>
                <!-- Inicio de las tarjetas de pacientes -->
                <div class="row row-cols-1 row-cols-md-4 g-4">
                    <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col">
                            <div class="card" style="height: auto;">
                                <!-- Encabezado de la tarjeta -->
                                <div class="card-header border-0"
                                     style="display: flex; justify-content: space-between;">
                                    <div>
                                        <p class="text-body-table"><strong><?php echo e($patient->name); ?></strong></p>
                                        <p class="text-body-table"
                                           id="num_identification"><?php echo e($patient->identification); ?></p>
                                    </div>
                                    <i class="bi bi-person-square" style="font-size: 3.4rem;"></i>
                                </div>
                                <!-- Cuerpo de la tarjeta -->
                                <div class="card-content" style="max-height: 200px; overflow: auto;">
                                    <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($key == $patient->id && count($value) > 0): ?>
                                            <?php $shownActivities = 0; ?>
                                            <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jsonData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($shownActivities < 3): ?>
                                                    <div class="card-body">
                                                        <ul>
                                                            <li class="text-body-table ">
                                                                <i class="bi bi-check2 icon-negro">
                                                                    <?php echo e($jsonData->name_activity); ?>

                                                                </i>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <?php $shownActivities++; ?>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            <?php if(count($value) > $shownActivities): ?>
                                                <div class="card-body">
                                                    <ul>
                                                        <li class="text-body-table">
                                                            <span>...</span>
                                                        </li>
                                                    </ul>
                                                </div>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>

                                <!-- Pie de la tarjeta -->
                                <div class="card-footer border-0 d-flex justify-content-between align-items-center"
                                     style="padding-left: 10px; padding-right: 10px;">
                                    <a class="button-card a" href="<?php echo e(route('activities', ['filter' => $patient->id])); ?>">Ver
                                        todas</a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <!-- Fin de las tarjetas de pacientes -->
            </div>
            <?php echo e($patients->links('vendor.pagination.simple-bootstrap-5')); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Work\personal\medisync\resources\views/doctor/dashboardpatient.blade.php ENDPATH**/ ?>