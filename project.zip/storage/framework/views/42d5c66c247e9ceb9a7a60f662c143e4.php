<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-center align-items-center p-5">
        <div class="card mb-3 border-0 " style="">
            <a class="card-title text-body-title">Editar información de un paciente:</a>
            <p class="card-text">
            <form action="<?php echo e(route('saveedit')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="input-group mb-3">
                    <span class="input-group-text" id="inputGroup-sizing-default">Nombre completo</span>
                    <input id="name" name="name" type="text" class="form-control"
                           aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" maxlength="255"
                           value="<?php echo e($patients->name); ?>" required>
                </div>
                <input type="hidden" id="patient_id" name="patient_id" value="<?php echo e($patients->id); ?>">
                <div class="input-group mb-3">
                    <span class="input-group-text" id="inputGroup-sizing-default">Cédula</span>
                    <input id="identification" name="identification" type="text" class="form-control"
                           aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" maxlength="255"
                           value="<?php echo e($patients->identification); ?>" required>
                </div>
                <div class="input-group mb-3">
                    <span class="input-group-text" id="inputGroup-sizing-default">Sexo</span>
                    <select id="sex" name="sex" class="form-select" aria-label="Default select example" required>
                        <option selected>Selecciona una opción</option>
                        <option value="MEN" <?php echo e($patients->sex == 'MEN' ? 'selected':''); ?>>Hombre</option>
                        <option value="FEMALE" <?php echo e($patients->sex == 'FEMALE' ? 'selected':''); ?>>Mujer</option>
                    </select>
                </div>
                <div class="input-group mb-3">
                    <span class="input-group-text" id="inputGroup-sizing-default">Fecha de nacimiento</span>
                    <input id="birth_date" name="birth_date" type="date" class="form-control"
                           aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" max="<?php echo e(date('Y-m-d')); ?>"
                           value="<?php echo e($patients->birth_date); ?>" required>
                </div>
                <div class="input-group mb-3">
                    <span class="input-group-text" id="inputGroup-sizing-default">Fecha de ingreso</span>
                    <input id="in_date" name="in_date" type="date" class="form-control" max="<?php echo e(date('Y-m-d')); ?>"
                           aria-label="Sizing example input"
                           aria-describedby="inputGroup-sizing-default" maxlength="255" value="<?php echo e($patients->in_date); ?>" required>
                </div>
                <div class="input-group mb-3">
                    <span class="input-group-text" id="inputGroup-sizing-default">Habitación</span>
                    <input id="room" name="room" type="text" class="form-control" aria-label="Sizing example input"
                           aria-describedby="inputGroup-sizing-default" maxlength="255" value="<?php echo e($patients->room); ?>" required>
                </div>
                <div class="d-flex justify-content-start">
                    <div class="pr-5">
                        <button type="submit" class="button-usuario" style="margin-right: 5px;">Guardar</button>
                    </div>
                    <div>
                        <a href="<?php echo e(route('patient')); ?>" class="button-regresar a">Cancelar</a>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Work\personal\medisync\resources\views/doctor/editpatient.blade.php ENDPATH**/ ?>