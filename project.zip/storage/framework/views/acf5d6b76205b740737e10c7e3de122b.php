<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-center align-items-center p-5">
    <div class="card mb-3 border-0" style="">
        <div class="row g-0">
            <div class="col-md-8">
                <div class="card-body">
                    <h5 class="card-title text-body-big">Bienvenido Doctor !</h5>
                    <p class="card-text text-body-medium2">INGRESA UN NUEVO <span class="font-weight-bold">PACIENTE&nbsp;&nbsp;&nbsp;</span>
                        <a type="button" class="button-body text-decoration-none" href="<?php echo e(route('registerpatient')); ?>">
                            Registrar&nbsp;&nbsp;
                        </a>
                    </p>
                    <p class="card-text text-body-small">Con MediSync puedes mantener al día todos los datos de tus
                        pacientes, al igual que los medicamentos administrados y por administrar. Además de mantener al
                        día tus inventarios de medicamentos.</p>
                </div>
            </div>
            <div class="col-md-4">
                <img class="img-responsive" src="<?php echo e(asset('images/doctora.png')); ?>">
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Work\personal\medisync\resources\views/doctor/home.blade.php ENDPATH**/ ?>