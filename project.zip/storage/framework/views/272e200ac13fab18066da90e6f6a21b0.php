<?php $__env->startSection('content'); ?>

    <div class="d-flex p-4">
        <div class="container">
            <p class="card-title text-aling-left text-body-title pb-3">Actividades</p>
            <div class="card mb-3">
                <div class="card-header">
                    <form action="<?php echo e(route('activities')); ?>" method="get">
                        <div class="d-flex flex-row align-items-start">
                            <input type="text" class="form-control busqueda" name="texto" value="<?php echo e($texto); ?>">
                            <input type="submit" class="btn btn-primary mx-2 button-buscar" value="Buscar">
                        </div>
                    </form>
                </div>
                <?php if(Auth::check()): ?>
                    <?php switch(Auth::user()->role):
                        case ('ADMIN'): ?>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-md">
                                        <thead>
                                        <tr>
                                            <th scope="col" class="text-body">Nombre</th>
                                            <th scope="col" class="text-body">Permisos</th>
                                            <th scope="col" class="text-body">Temporalidad</th>
                                            <th scope="col" class="text-body">Horario</th>
                                            <th scope="col" class="text-body">Medicamentos</th>
                                            <th scope="col" class="text-body">Dosis</th>
                                            <th scope="col" class="text-body">vía</th>
                                            <th scope="col" class="text-body">Fecha de creacion</th>
                                            <th scope="col" class="text-body">Fecha de suspensión</th>
                                            <th scope="col" style="max-width: 120px;"></th>
                                            <th scope="col" style="max-width: 120px;"></th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php if(count($activities)<=0): ?>
                                            <tr>
                                                <td>No hay resultado</td>
                                            </tr>
                                        <?php else: ?>
                                            <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo $__env->make('doctor.deleteActivityModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                <tr>
                                                    <td class="text-body-table">
                                                        <strong><?php echo e($activity->name_activity); ?></strong></td>
                                                    <td class="text-body-table"><?php echo e(__('passwords.'.$activity->min_permissions)); ?></td>
                                                    <td class="text-body-table"><?php echo e(__('passwords.'.$activity->temporality)); ?></td>
                                                    <td class="text-body-table"><?php echo e($activity->schedule); ?></td>
                                                    <td class="text-body-table"><?php echo e($activity->medicine_id); ?></td>
                                                    <td class="text-body-table"><?php echo e($activity->dose); ?></td>
                                                    <td class="text-body-table"><?php echo e($activity->via); ?></td>
                                                    <td class="text-body-table"><?php echo e($activity->create_date); ?></td>
                                                    <td class="text-body-table"><?php echo e($activity->suspension_date); ?></td>
                                                    <td>

                                                    </td>
                                                    <td>
                                                        <a>
                                                            <button type="button" data-bs-toggle="modal"
                                                                    data-
                                                                    data-bs-target="#deleteActivityModal<?php echo e($activity->id); ?>"
                                                                    style="border: none; background: none">
                                                                <i class="bi bi-trash" style="font-size: 1.4rem;"></i>
                                                            </button>

                                                        </a>
                                                    </td>
                                                    <td>

                                                        <a href="<?php echo e(route('editactivity', ['id' => $activity->id])); ?>">
                                                            <i class="bi bi-pencil-square"
                                                               style="font-size: 1.4rem;"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <?php break; ?>
                        <?php case ('DOCTOR'): ?>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-md">
                                        <thead>
                                        <tr>
                                            <th scope="col" class="text-body">Nombre</th>
                                            <th scope="col" class="text-body">Permisos</th>
                                            <th scope="col" class="text-body">Temporalidad</th>
                                            <th scope="col" class="text-body">Horario</th>
                                            <th scope="col" class="text-body">Medicamentos</th>
                                            <th scope="col" class="text-body">Dosis</th>
                                            <th scope="col" class="text-body">vía</th>
                                            <th scope="col" class="text-body">Fecha de creacion</th>
                                            <th scope="col" class="text-body">Fecha de suspensión</th>
                                            <th scope="col" style="max-width: 120px;"></th>
                                            <th scope="col" style="max-width: 120px;"></th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php if(count($activities)<=0): ?>
                                            <tr>
                                                <td>No hay resultado</td>
                                            </tr>
                                        <?php else: ?>
                                            <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo $__env->make('doctor.deleteActivityModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                <tr>
                                                    <td class="text-body-table">
                                                        <strong><?php echo e($activity->name_activity); ?></strong></td>
                                                    <td class="text-body-table"><?php echo e(__('passwords.'.$activity->min_permissions)); ?></td>
                                                    <td class="text-body-table"><?php echo e(__('passwords.'.$activity->temporality)); ?></td>
                                                    <td class="text-body-table"><?php echo e($activity->schedule); ?></td>
                                                    <td class="text-body-table"><?php echo e($activity->medicine_id); ?></td>
                                                    <td class="text-body-table"><?php echo e($activity->dose); ?></td>
                                                    <td class="text-body-table"><?php echo e($activity->via); ?></td>
                                                    <td class="text-body-table"><?php echo e($activity->create_date); ?></td>
                                                    <td class="text-body-table"><?php echo e($activity->suspension_date); ?></td>
                                                    <td>

                                                    </td>
                                                    <td>
                                                        <a>
                                                            <button type="button" data-bs-toggle="modal"
                                                                    data-
                                                                    data-bs-target="#deleteActivityModal<?php echo e($activity->id); ?>"
                                                                    style="border: none; background: none">
                                                                <i class="bi bi-trash" style="font-size: 1.4rem;"></i>
                                                            </button>

                                                        </a>
                                                    </td>
                                                    <td>

                                                        <a href="<?php echo e(route('editactivity', ['id' => $activity->id])); ?>">
                                                            <i class="bi bi-pencil-square"
                                                               style="font-size: 1.4rem;"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <?php break; ?>
                        <?php case ('BOSS_NURSE'): ?>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-md">
                                        <thead>
                                        <tr>
                                            <th scope="col" class="text-body">Nombre</th>
                                            <th scope="col" class="text-body">Permisos</th>
                                            <th scope="col" class="text-body">Temporalidad</th>
                                            <th scope="col" class="text-body">Horario</th>
                                            <th scope="col" class="text-body">Medicamentos</th>
                                            <th scope="col" class="text-body">Dosis</th>
                                            <th scope="col" class="text-body">vía</th>
                                            <th scope="col" class="text-body">Fecha de creacion</th>
                                            <th scope="col" class="text-body">Fecha de suspensión</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php if(count($activities)<=0): ?>
                                            <tr>
                                                <td>No hay resultado</td>
                                            </tr>
                                        <?php else: ?>
                                            <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo $__env->make('doctor.deleteActivityModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                <tr>
                                                    <td class="text-body-table">
                                                        <strong><?php echo e($activity->name_activity); ?></strong></td>
                                                    <td class="text-body-table"><?php echo e(__('passwords.'.$activity->min_permissions)); ?></td>
                                                    <td class="text-body-table"><?php echo e(__('passwords.'.$activity->temporality)); ?></td>
                                                    <td class="text-body-table"><?php echo e($activity->schedule); ?></td>
                                                    <td class="text-body-table"><?php echo e($activity->medicine_id); ?></td>
                                                    <td class="text-body-table"><?php echo e($activity->dose); ?></td>
                                                    <td class="text-body-table"><?php echo e($activity->via); ?></td>
                                                    <td class="text-body-table"><?php echo e($activity->create_date); ?></td>
                                                    <td class="text-body-table"><?php echo e($activity->suspension_date); ?></td>
                                                    <td>

                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <?php break; ?>
                        <?php case ('NURSE'): ?>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-md">
                                        <thead>
                                        <tr>
                                            <th scope="col" class="text-body">Nombre</th>
                                            <th scope="col" class="text-body">Permisos</th>
                                            <th scope="col" class="text-body">Temporalidad</th>
                                            <th scope="col" class="text-body">Horario</th>
                                            <th scope="col" class="text-body">Medicamentos</th>
                                            <th scope="col" class="text-body">Dosis</th>
                                            <th scope="col" class="text-body">vía</th>
                                            <th scope="col" class="text-body">Fecha de creacion</th>
                                            <th scope="col" class="text-body">Fecha de suspensión</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php if(count($activities)<=0): ?>
                                            <tr>
                                                <td>No hay resultado</td>
                                            </tr>
                                        <?php else: ?>
                                            <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo $__env->make('doctor.deleteActivityModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                <tr>
                                                    <td class="text-body-table">
                                                        <strong><?php echo e($activity->name_activity); ?></strong></td>
                                                    <td class="text-body-table"><?php echo e(__('passwords.'.$activity->min_permissions)); ?></td>
                                                    <td class="text-body-table"><?php echo e(__('passwords.'.$activity->temporality)); ?></td>
                                                    <td class="text-body-table"><?php echo e($activity->schedule); ?></td>
                                                    <td class="text-body-table"><?php echo e($activity->medicine_id); ?></td>
                                                    <td class="text-body-table"><?php echo e($activity->dose); ?></td>
                                                    <td class="text-body-table"><?php echo e($activity->via); ?></td>
                                                    <td class="text-body-table"><?php echo e($activity->create_date); ?></td>
                                                    <td class="text-body-table"><?php echo e($activity->suspension_date); ?></td>
                                                    <td>

                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <?php break; ?>
                    <?php endswitch; ?>
                <?php endif; ?>
                <?php echo e($activities->links('vendor.pagination.simple-bootstrap-5')); ?>

            </div>
            <a href="<?php echo e(route('dashboardpatient')); ?>" class="button-regresar a">Regresar</a>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Work\personal\medisync\resources\views/doctor/activities.blade.php ENDPATH**/ ?>