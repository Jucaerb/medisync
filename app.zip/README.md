![9d8f4ac7-70e6-4f94-bbd8-0fd55242c1cf](https://github.com/capicodev2/medisync/assets/43945112/16433c1c-b8f3-4a8d-9cfc-cccca718e281)
