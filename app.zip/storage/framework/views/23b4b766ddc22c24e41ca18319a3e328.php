<?php $__env->startSection('content'); ?>
    <div class="d-flex p-4">
        <div class="container">
            <p class="card-title text-aling-left text-body-title pb-3">Atenciones pendientes</p>
            <div class="card mb-3">
                <div class="card-header">
                    <form action="<?php echo e(route('pendingList')); ?>" method="get">
                        <div class="d-flex flex-row align-items-start">
                            <input type="text" class="form-control busqueda" name="texto" value="<?php echo e($texto); ?>">
                            <input type="submit" class="btn btn-primary mx-2 button-buscar" value="Buscar">
                        </div>
                    </form>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-md">
                            <thead>
                            <tr>
                                <th scope="col" class="text-body">Actividad</th>
                                <th scope="col" class="text-body">Medicamento</th>
                                <th scope="col" class="text-body">Hora</th>
                                <th scope="col" class="text-body">Permisos</th>
                                <th scope="col" class="text-body">Habitación</th>
                                <th scope="col" class="text-body">Fecha</th>
                                <th scope="col" style="max-width: 120px;"></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $attention; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jsonData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo $__env->make('boss_nurse.attentionModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php echo $__env->make('boss_nurse.registerAttentionModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <tr>
                                    <td class="text-body-table">
                                        <strong><?php echo e($jsonData->activity_name); ?></strong>
                                    </td>
                                    <td class="text-body-table"><?php echo e($jsonData->medicine_id); ?></td>
                                    <td class="text-body-table"><?php echo e(\Carbon\Carbon::createFromFormat('H',$jsonData->hour)->format('H:i')); ?></td>
                                    <td class="text-body-table"><?php echo e(__('passwords.'.$jsonData->min_permissions)); ?></td>
                                    <td class="text-body-table"><?php echo e($jsonData->room); ?></td>
                                    <td class="text-body-table"><?php echo e($jsonData->date_for); ?></td>
                                    <td>
                                        <button type="button" data-bs-toggle="modal"
                                                data-bs-target="#attentionModal<?php echo e($jsonData->id); ?>"
                                                style="border: none; background: none">
                                            <i class="bi bi-eye-fill"
                                               style="font-size: 1rem; "></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php echo e($attention->links('vendor.pagination.simple-bootstrap-5')); ?>

            </div>
            <a href="<?php echo e(route('pending')); ?>" class="button-regresar a">Regresar</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Work\personal\medisync\resources\views/boss_nurse/pendingList.blade.php ENDPATH**/ ?>