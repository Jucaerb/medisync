<?php echo e($slot); ?>

<?php /**PATH E:\Work\personal\medisync\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>