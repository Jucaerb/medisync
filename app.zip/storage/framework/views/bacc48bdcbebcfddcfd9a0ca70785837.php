<?php $__env->startSection('content'); ?>

    <div class="d-flex p-4">
        <div class="container">
            <p class="card-title text-aling-left text-body-title pb-3">Mira tus empleados activos!</p>
            <div class="card mb-3">
                <div class="card-header">
                    <div class="d-flex justify-content-between align-items-center">
                        <a href="<?php echo e(route('admin.registeruser')); ?>" class="button-add a ">+ Añadir empleado</a>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-md">
                            <thead>
                            <tr>
                                <th scope="col" class="text-body">Usuario</th>
                                <th scope="col" class="text-body">Nombre completo</th>
                                <th scope="col" class="text-body">Rol</th>
                                <th scope="col" class="text-body">Email</th>
                                <th scope="col" class="text-body">Identificación</th>
                                <th scope="col" class="text-body">Estado</th>
                                <th scope="col" style="max-width: 120px;"></th>
                                <th scope="col" style="max-width: 120px;"></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo $__env->make('admin.inactiveModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php echo $__env->make('admin.activateModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <tr>
                                    <td class="text-body-table"> <strong><?php echo e($user->username); ?></strong></td>
                                    <td class="text-body-table"><?php echo e($user->full_name); ?></td>
                                    <td class="text-body-table"><?php echo e(__('passwords.'.$user->role)); ?></td>
                                    <td class="text-body-table"><?php echo e($user->email); ?></td>
                                    <td class="text-body-table"><?php echo e($user->identification_number); ?></td>
                                    <td>
                                        <?php if($user->status == 'ACTIVE'): ?>

                                            <span class=" bi bi-dot badge rounded-pill custom-badge-active" style="font-size: 0.9rem;">
                                            <?php echo e(ucfirst(strtolower($user->status))); ?>

                                        </span>
                                        <?php else: ?>
                                            <span class=" bi bi-dot badge rounded-pill custom-badge-inactive" style="font-size: 0.9rem;">
                                            <?php echo e(ucfirst(strtolower($user->status))); ?>

                                        </span>
                                        <?php endif; ?>

                                    </td>
                                    <td>
                                    <td>
                                        <a href="<?php echo e(route('admin.edituser', ['id' => $user->id])); ?>">
                                            <i class="bi bi-pencil-square" style="font-size: 1.4rem;"></i>
                                        </a>
                                    </td>
                                    <td>
                                        <?php if($user->status == 'ACTIVE'): ?>
                                            <button type="button" data-bs-toggle="modal" data-bs-target="#inactiveModal<?php echo e($user->id); ?>"
                                                    style="border: none; background: none">
                                                <i class="bi bi-toggle-on" style="font-size: 1.4rem; "></i>
                                            </button>
                                        <?php else: ?>
                                            <button type="button" data-bs-toggle="modal" data-bs-target="#activateModal<?php echo e($user->id); ?>"
                                                    style="border: none; background: none">
                                                <i class="bi bi-toggle-off" style="font-size: 1.4rem;"></i>
                                            </button>
                                        <?php endif; ?>
                                    </td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <a href="<?php echo e(route('admin.home')); ?>" class="button-regresar a">Regresar</a>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Work\personal\medisync\resources\views/admin/users.blade.php ENDPATH**/ ?>