<?php $__env->startSection('content'); ?>

    <div class="d-flex p-4">
        <div class="container">
            <p class="card-title text-aling-left text-body-title pb-3">Mira tus pacientes</p>
            <div class="card mb-3">
                <div class="card-header">
                    <form action="<?php echo e(route('patient')); ?>" method="get">
                        <div class="d-flex flex-row align-items-start">
                            <input type="text" class="form-control busqueda" name="texto" value="<?php echo e($texto); ?>">
                            <input type="submit" class="btn btn-primary mx-2 button-buscar" value="Buscar">
                            <a href="<?php echo e(route('registerpatient')); ?>" class="button-add a mx-2">+ Añadir paciente</a>
                        </div>
                    </form>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-md">
                            <thead>
                            <tr>
                                <th scope="col" class="text-body">Nombre completo</th>
                                <th scope="col" class="text-body">Fecha de ingreso</th>
                                <th scope="col" class="text-body">Sexo</th>
                                <th scope="col" class="text-body">Fecha de nacimiento</th>
                                <th scope="col" class="text-body">Identificación</th>
                                <th scope="col" class="text-body">Habitación</th>
                                <th scope="col" class="text-body">Estado</th>
                                <th scope="col" style="max-width: 120px;"></th>
                                <th scope="col" style="max-width: 120px;"></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php if(count($patients)<=0): ?>
                                <tr>
                                    <td>No hay resultado</td>
                                </tr>
                            <?php else: ?>
                                <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo $__env->make('doctor.inactiveModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php echo $__env->make('doctor.activateModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <tr>
                                        <td class="text-body-table"><strong><?php echo e($patient->name); ?></strong></td>
                                        <td class="text-body-table"><?php echo e($patient->in_date); ?></td>
                                        <td class="text-body-table"><?php echo e(__('passwords.'.$patient->sex)); ?></td>
                                        <td class="text-body-table"><?php echo e($patient->birth_date); ?></td>
                                        <td class="text-body-table"><?php echo e($patient->identification); ?></td>
                                        <td class="text-body-table"><?php echo e($patient->room); ?></td>
                                        <td>
                                            <?php if($patient->status == 'ACTIVE'): ?>

                                                <span class=" bi bi-dot badge rounded-pill custom-badge-active"
                                                      style="font-size: 0.9rem;">
                                            <?php echo e(ucfirst(strtolower($patient->status))); ?>

                                        </span>
                                            <?php else: ?>
                                                <span class=" bi bi-dot badge rounded-pill custom-badge-inactive"
                                                      style="font-size: 0.9rem;">
                                            <?php echo e(ucfirst(strtolower($patient->status))); ?>

                                        </span>
                                            <?php endif; ?>

                                        </td>
                                        <td>
                                        </td>
                                        <td>

                                            <a href="<?php echo e(route('editpatient', ['id' => $patient->id])); ?>">
                                                <i class="bi bi-pencil-square" style="font-size: 1.4rem;"></i>
                                            </a>
                                        </td>
                                        <td>
                                            <?php if($patient->status == 'ACTIVE'): ?>
                                                <button type="button" data-bs-toggle="modal"
                                                        data-bs-target="#inactiveModal<?php echo e($patient->id); ?>"
                                                        style="border: none; background: none">
                                                    <i class="bi bi-toggle-on" style="font-size: 1.4rem; "></i>
                                                </button>
                                            <?php else: ?>
                                                <button type="button" data-bs-toggle="modal"
                                                        data-bs-target="#activateModal<?php echo e($patient->id); ?>"
                                                        style="border: none; background: none">
                                                    <i class="bi bi-toggle-off" style="font-size: 1.4rem;"></i>
                                                </button>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php echo e($patients->links('vendor.pagination.simple-bootstrap-5')); ?>

            </div>
            <a href="<?php echo e(route('home')); ?>" class="button-regresar a">Regresar</a>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Work\personal\medisync\resources\views/doctor/patient.blade.php ENDPATH**/ ?>