<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH E:\Work\personal\medisync\resources\views/vendor/mail/text/button.blade.php ENDPATH**/ ?>